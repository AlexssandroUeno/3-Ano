/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unifil.javaconnection.views.tablemodels;

import edu.unifil.javaconnection.controllers.PessoaController;
import edu.unifil.javaconnection.models.Pessoa;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author mhadaniya
 */
public class PessoaTableModel extends AbstractTableModel {

    Pessoa listaPessoas[];
    PessoaController pessoaController;

    public PessoaTableModel() {
        pessoaController = new PessoaController();
        try {
            listaPessoas = pessoaController.list();
        } catch (Exception ex) {
            Logger.getLogger(PessoaTableModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    @Override
    public int getRowCount() {
        if(listaPessoas.length > 0){
            return listaPessoas.length;
        }else{
            return 0;
        }
        
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return listaPessoas[rowIndex].getId();
            
            case 1:
                return listaPessoas[rowIndex].getNome();
                
            case 2:
                return listaPessoas[rowIndex].getIdade();
                
            case 3:
                return listaPessoas[rowIndex].getEmail();
                                
            default:               
                return listaPessoas[rowIndex].getId();
        }                
    }

    @Override
    public String getColumnName(int column) {
        switch(column){
             case 0:
                return "id";
            
            case 1:
                return "nome";
                
            case 2:
                return "email";
                
            case 3:
                return "idade";
                                
            default:               
                return "#error";
        }        
    }
    
    
    
}
