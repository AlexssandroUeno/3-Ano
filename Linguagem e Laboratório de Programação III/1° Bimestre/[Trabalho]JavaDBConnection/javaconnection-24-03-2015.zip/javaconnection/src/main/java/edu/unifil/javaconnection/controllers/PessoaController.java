/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unifil.javaconnection.controllers;

import edu.unifil.javaconnection.db.ConexaoMySQL;
import edu.unifil.javaconnection.models.Pessoa;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author mhadaniya
 */
public class PessoaController {
        
    public Pessoa[] list() throws Exception{
                
        String query = "SELECT count(*) FROM pessoa";
        Statement st = ConexaoMySQL.getConexao().createStatement();
        ResultSet rs = st.executeQuery(query);
        
        int numPessoas = 0;
        while (rs.next()) {
            numPessoas = rs.getInt(1);
        }
        Pessoa[] pessoas = new Pessoa[numPessoas];
        
        query = "SELECT * FROM pessoa";
        rs = st.executeQuery(query);        
        
        int count = 0;
        while (rs.next())
        { 
            Pessoa p = new Pessoa();
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setIdade(rs.getInt("idade"));
            p.setEmail(rs.getString("email"));
            pessoas[count] = p;
            count++;
        }
        
        st.close();
        
        return pessoas;         
      }          
    
    
}
