/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mat;

import java.awt.GridLayout;
import java.text.DecimalFormat;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author Guidetti
 */
public class Tela extends javax.swing.JFrame
{

    JTextField[][] txMatrixU, txMatrixL;
    JTextField[] txResultadosX;
    double multiplicadoresMatriz[][];
    double global_matrix[][];
    int row, col;
    double[] sltn;
    int buffer;
    int n;

    /**
     * Creates new form Tela
     */
    public Tela()
    {
        initComponents();
        this.setLocationRelativeTo(null);
        txRow.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override
            public void insertUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();
                }
            }
        });

        txColumn.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override
            public void insertUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();

                }
            }

            @Override
            public void removeUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();

                }
            }

            @Override
            public void changedUpdate(DocumentEvent e)
            {
                if (txRow.getText().trim().length() > 0 && txColumn.getText().trim().length() > 0)
                {
                    gerarMatrizL();
                    gerarMatrizU();
                    gerarOResto();
                }
            }
        });
    }

    private void before(double valores[][])
    {
        int m1 = 0;
        while (m1 < valores.length)
        {
            for (int i = m1 + 1; i < valores.length; i++)
            {
                multiplicadoresMatriz[i][m1] = valores[i][m1] / valores[m1][m1];
            }
            m1++;
        }

        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                if (i == j)
                {
                    multiplicadoresMatriz[i][j] = 1;
                }
            }
        }

        int m = 0;
        while (m < valores.length)
        {
            for (int i = m + 1; i < valores.length; i++)
            {
                double multiplicador = valores[i][m] / valores[m][m];

                for (int j = 0; j < valores[i].length; j++)
                {
                    double r = valores[i][j] - (multiplicador * valores[m][j]);
                    valores[i][j] = r;
                }
            }
            m++;
        }
        for (int i = 0; i < valores.length; i++)
        {
            for (int j = 0; j < valores[i].length; j++)
            {
                txMatrixL[i][j].setText(converterDoubleQuatroDecimais(valores[i][j]) + "");
            }
        }
    }

    private void doMath()
    {
        conta(global_matrix);

        for (int i = 0; i < sltn.length; i++)
        {
            txResultadosX[i].setText("" + converterDoubleQuatroDecimais(sltn[i]));
        }
    }

    public void conta(double matrix[][])
    {
        for (int i = n - 1; i != -1; i--)
        {
            if (i == (n - 1))
            {
                sltn[i] = (matrix[i][buffer - 1]) / matrix[i][i];
            } else
            {
                sltn[i] = (matrix[i][buffer - 1] - somatoria(i)) / matrix[i][i];
            }
        }

    }

    public double somatoria(int i)
    {
        double somatoria = 0;
        for (int j = i + 1; j != n; j++)
        {
            somatoria += (global_matrix[i][j]) * sltn[j];
        }
        return somatoria;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jRadioButton1 = new javax.swing.JRadioButton();
        paneMatrizU = new javax.swing.JPanel();
        txRow = new javax.swing.JTextField();
        txColumn = new javax.swing.JTextField();
        labLinha = new javax.swing.JLabel();
        labColuna = new javax.swing.JLabel();
        btnCalcular = new javax.swing.JButton();
        paneTxResultados = new javax.swing.JPanel();
        paneMatrizL = new javax.swing.JPanel();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        paneMatrizU.setBorder(javax.swing.BorderFactory.createTitledBorder("Matriz - U"));
        paneMatrizU.setLayout(new java.awt.GridLayout(1, 0));

        labLinha.setText("Linha:");

        labColuna.setText("Coluna:");

        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCalcularActionPerformed(evt);
            }
        });

        paneTxResultados.setBorder(javax.swing.BorderFactory.createTitledBorder("resultado"));

        javax.swing.GroupLayout paneTxResultadosLayout = new javax.swing.GroupLayout(paneTxResultados);
        paneTxResultados.setLayout(paneTxResultadosLayout);
        paneTxResultadosLayout.setHorizontalGroup(
            paneTxResultadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 278, Short.MAX_VALUE)
        );
        paneTxResultadosLayout.setVerticalGroup(
            paneTxResultadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
        );

        paneMatrizL.setBorder(javax.swing.BorderFactory.createTitledBorder("Matriz - L"));

        javax.swing.GroupLayout paneMatrizLLayout = new javax.swing.GroupLayout(paneMatrizL);
        paneMatrizL.setLayout(paneMatrizLLayout);
        paneMatrizLLayout.setHorizontalGroup(
            paneMatrizLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        paneMatrizLLayout.setVerticalGroup(
            paneMatrizLLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(paneTxResultados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(paneMatrizL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(paneMatrizU, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(labLinha)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txRow, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(labColuna)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txColumn, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(178, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txRow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txColumn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labLinha)
                    .addComponent(labColuna)
                    .addComponent(btnCalcular))
                .addGap(18, 18, 18)
                .addComponent(paneMatrizL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(paneTxResultados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(paneMatrizU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(317, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCalcularActionPerformed
    {//GEN-HEADEREND:event_btnCalcularActionPerformed
        if (txColumn.getText().trim().length() > 0 && txRow.getText().trim().length() > 0)
        {
            global_matrix = new double[row][col];
            multiplicadoresMatriz = new double[row][col];
            preencheMatrix();
            before(global_matrix);
            preencheMatrix();
            doMath();
            setMatrizU();
        } else
        {
            JOptionPane.showMessageDialog(null, "Insira o tamanho da matriz, suas linhas e colunas");
            if (txColumn.getText().trim().length() > 0)
            {
                txColumn.setFocusable(true);
            } else if (txRow.getText().trim().length() > 0)
            {
                txRow.setFocusable(true);
            }
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void setMatrizU()
    {
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                this.txMatrixU[i][j].setText(""+multiplicadoresMatriz[i][j]);
            }
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Windows".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Tela.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Tela.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Tela.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Tela.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Tela().setVisible(true);
            }
        });
    }

    private void gerarMatrizU()
    {
        this.paneMatrizU.removeAll();

        this.paneMatrizU.setLayout(new GridLayout(row, col));
        
        this.txMatrixU = new JTextField[row][col];
        
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                JTextField a = new JTextField();
                 this.txMatrixU[i][j] = a;
                a.setText("0");
                this.paneMatrizU.add(a);
            }
        }
        paneMatrizU.updateUI();
    }

    private void gerarMatrizL()
    {
        this.paneMatrizL.removeAll();

        row = Integer.parseInt(txRow.getText());
        col = Integer.parseInt(txColumn.getText());

        this.paneMatrizL.setLayout(new GridLayout(row, col));

        this.txMatrixL = new JTextField[row][col];

        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                JTextField a = new JTextField();
                this.txMatrixL[i][j] = a;
                a.setText("0");
                this.paneMatrizL.add(a);
            }
        }
        paneMatrizL.updateUI();
    }

    private void preencheMatrix()
    {
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                global_matrix[i][j] = converterDoubleQuatroDecimais(Double.parseDouble(txMatrixL[i][j].getText()));
            }
        }

        sltn = new double[global_matrix.length];
        buffer = global_matrix[1].length;
        n = global_matrix.length;
    }

    private void gerarOResto()
    {
        paneTxResultados.removeAll();
        int _row_ = col - 1;
        int column = 1;
        txResultadosX = new JTextField[_row_];
        paneTxResultados.setLayout(new GridLayout(_row_, column));

        for (int i = 0; i < _row_; i++)
        {
            for (int j = 0; j < column; j++)
            {
                JLabel labelX = new JLabel("x" + (i + 1) + "=");
                JTextField resultX = new JTextField(15);
                txResultadosX[i] = resultX;
                paneTxResultados.add(labelX);
                paneTxResultados.add(resultX);
            }
        }
        paneTxResultados.updateUI();

    }


    public static double converterDoubleQuatroDecimais(double precoDouble)
    {
        DecimalFormat fmt = new DecimalFormat("0.000");
        String string = fmt.format(precoDouble);
        String[] part = string.split("[,]");
        String string2 = part[0] + "." + part[1];
        double preco = Double.parseDouble(string2);
        return preco;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JLabel labColuna;
    private javax.swing.JLabel labLinha;
    private javax.swing.JPanel paneMatrizL;
    private javax.swing.JPanel paneMatrizU;
    private javax.swing.JPanel paneTxResultados;
    private javax.swing.JTextField txColumn;
    private javax.swing.JTextField txRow;
    // End of variables declaration//GEN-END:variables

}
