package mvc.model;

import mvc.utils.Dicionario;

/**
 *
 * @author mhadaniya
 */
public class NomeList {
    private NomeModel nomes[];

    public NomeList() {
        nomes = new NomeModel[10];
        int rand = 0, minimum = 0, maximum = Dicionario.NOMES.length;
        for (int i = 0; i < nomes.length; i++){
            rand = minimum + (int)(Math.random()*maximum);
            nomes[i] = new NomeModel(Dicionario.NOMES[rand]);
        }        
    }

    public NomeList(NomeModel[] nomes) {
        this.nomes = nomes;
    }
    
    public void setNomeAtPosition(int position, String nome){
        this.nomes[position] = new NomeModel(nome);
    }
    
    public NomeModel getNomeAtPosition(int position){
        return this.nomes[position];
    }

    public NomeModel[] getNomes() {
        return nomes;
    }

    public void setNomes(NomeModel[] nomes) {
        this.nomes = nomes;
    }
    
    
}
