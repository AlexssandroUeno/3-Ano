package mvc.model;

/**
 *
 * @author mhadaniya
 */
public class NomeModel {
    private String nome;

    public NomeModel() {
    }

    public NomeModel(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return this.nome;
    }
    
}
