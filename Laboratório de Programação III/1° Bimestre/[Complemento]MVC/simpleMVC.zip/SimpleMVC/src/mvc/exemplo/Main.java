package mvc.exemplo;

import mvc.controller.PessoaController;

/**
 *
 * @author mhadaniya
 */
public class Main {
        
    public static void main(String[] args) {
        
        PessoaController controller = new PessoaController();
        
    }
    
}
