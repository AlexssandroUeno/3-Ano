package mvc.controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import mvc.model.NomeList;
import mvc.view.View;

/**
 *
 * @author mhadaniya
 */
public class PessoaController {
    private NomeList nomeList = new NomeList();
    private View view = new View();   
    
    public PessoaController(){
                
        view.setVisible(true);
        
        view.getjList().setListData(nomeList.getNomes());        
        
        view.getjList().repaint();
        
        view.getjButton().addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
                
            }

            @Override
            public void mousePressed(MouseEvent e) {
                nomeList.setNomeAtPosition(0, view.getjTextField().getText());
                System.out.println("Yeah!");
                view.repaint();
        
                view.getjList().repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
               
            }

            @Override
            public void mouseExited(MouseEvent e) {
               
            }
        });
    }
    
    public void showAll(){
        for (int i = 0; i < nomeList.getNomes().length; i++) {
            System.out.println(nomeList.getNomeAtPosition(i));            
        }
    }
        
}
