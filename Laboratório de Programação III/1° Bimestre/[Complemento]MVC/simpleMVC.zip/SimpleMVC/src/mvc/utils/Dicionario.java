package mvc.utils;

/**
 *
 * @author mhadaniya
 */
public class Dicionario {
    public static String NOMES[] = {"Amanda", "Emekal", "Arlen", "Tonino", "Luiz",
                                    "Mario", "Alejo", "Gabriela", "Newton", "Samantha",
                                    "Luigi", "Bowser", "Ryu", "Ken", "Baraka",
                                    "Balrog", "Conan", "Link", "Zelda", "Totoro"};
    
    //randomNum = minimum + (int)(Math.random()*maximum); 
}
