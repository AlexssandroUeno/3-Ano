import java.awt.*;
import java.awt.geom.*;


/**
 * Desenhos.java
 * 
 * @author José Ricardo Guidetti Junior 
 * @version 14/03/2017
 */



public class Desenhos
{
   
    public static void desenhoLivre(Graphics2D pincel, Dimension dim) {
        int rec_x = 100, 
            rec_y = 100, 
            rec_height = 300, 
            rec_width  = 300,
            reducao = 100, spacing = 24;

        
        // Draw first Oval
        pincel.setColor(Color.blue);
        pincel.drawOval(rec_x, rec_y, rec_width, rec_height);
        pincel.fillOval(rec_x, rec_y, rec_width, rec_height);
       
        // Draw second Oval
        pincel.setColor(Color.yellow);
        pincel.fillOval(rec_x+rec_y-rec_y/2, rec_y+rec_y-rec_y/2, rec_width-rec_y, rec_height-rec_y);
        pincel.drawOval(rec_x+rec_y-rec_y/2, rec_y+rec_y-rec_y/2, rec_width-rec_y, rec_height-rec_y);
       
        int novo_x = rec_x+rec_y-rec_y/2;
        int novo_y = rec_y+rec_y-rec_y/2;
        int novo_w = rec_width-rec_y;
        int novo_h = rec_height-rec_y;
        // Draw Third Oval
        pincel.setColor(Color.red);
        pincel.fillOval(novo_x+novo_y-novo_y/2 -spacing, novo_y+novo_y-novo_y/2 -spacing, novo_w-reducao, novo_h-reducao);
        pincel.drawOval(novo_x+novo_y-novo_y/2 - spacing, novo_y+novo_y-novo_y/2 -spacing, novo_w-reducao, novo_h-reducao);
        
        
        // Draw Rectangle            
        pincel.setColor(Color.BLACK);
        pincel.drawRect(rec_x, rec_y, rec_width, rec_height);    

        
    }

    
    
    public static void desenharAsterisco(Graphics2D g2d) {
        throw new UnsupportedOperationException("O aluno ainda não implementou este método.");
    }
    
}
