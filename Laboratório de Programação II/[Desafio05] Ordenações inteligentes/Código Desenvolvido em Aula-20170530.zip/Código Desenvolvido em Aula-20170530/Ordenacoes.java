
import java.util.*;
/**
 * Write a description of class Ordenacoes here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ordenacoes {
    
        /**
         * Ordena crescentemente o arranjo pelo algoritmo da bolha,
         * in-place.
         * @param arr arranjo de inteiros a ser ordenado.
         */
        //     public static OperacoesOrdenacao bubblesort(Integer[] arr) {
        //         OperacoesOrdenacao medicoes = new OperacoesOrdenacao();
        //         
        //         boolean houveTroca;
        //         do {
        //             houveTroca = false;
        //             for (int i = 1; i < arr.length; i++) {
        //                 medicoes.qtdeComps++;
        //                 if (arr[i-1] > arr[i]) {
        //                     medicoes.qtdeEscrs += 2;
        //                     trocar(arr, i-1, i);
        //                     houveTroca = true;
        //                 }
        //             }
        //         } while(houveTroca);
        //         
        //         return medicoes;
        //     }
        
        /**
         * Ordena crescentemente o arranjo pelo algoritmo da seleção,
         * in-place.
         * @param arr arranjo de inteiros a ser ordenado.
         */
        //     public static OperacoesOrdenacao selectionsort(Integer[] arr) {
        //         OperacoesOrdenacao medicoes = new OperacoesOrdenacao();
        //         
        //         // Para cada posição, encontrar o elemento correto
        //         for (int i = 0; i < arr.length - 1; i++) {
        //             
        //             // Encontrar o menor elemento após o "i"
        //             int indiceMenor = i;
        //             for (int j = i+1; j < arr.length; j++) {
        //                 medicoes.qtdeComps++;
        //                 if (arr[indiceMenor] > arr[j]) {
        //                     indiceMenor = j;
        //                 }
        //             }
        //             
        //             // Coloca o elemento correto na posicao
        //             medicoes.qtdeEscrs += 2;
        //             trocar(arr, i, indiceMenor);
        //         }
        //         
        //         return medicoes;
        //     }
    
    /**
     * Ordena crescentemente o arranjo pelo algoritmo da inserção,
     * in-place.
     * @param arr arranjo de inteiros a ser ordenado.
     * Desempenho = 3n^2 + 4n;
     */
    public static OperacoesOrdenacao insertionsort(Integer[] arr) {
        OperacoesOrdenacao medicoes = new OperacoesOrdenacao();
        
        // Comprar cada carta
        for (int i = 1; i < arr.length; i++) { // n
            // Carta comprada
            int seguro = arr[i]; // n
            
            // Deslocar cartas para a direita, para abrir o espaço
            // correto da carta comprada.
            int j = i-1; // n
            while (j >= 0 && seguro < arr[j]) { // n * n
                medicoes.qtdeComps++;                
                medicoes.qtdeEscrs++;
                arr[j+1] = arr[j]; //n * n
                j--;// n * n
            }
            medicoes.qtdeComps++;
            
            // Colocar a carta no lugar
            medicoes.qtdeEscrs++;
            arr[j+1] = seguro; // n
        }
        
        return medicoes;
    }
    
     public static List<Integer> ListInsertionsort(List<Integer> arr) {
//         OperacoesOrdenacao medicoes = new OperacoesOrdenacao();
//     List<Integer> arr = Arrays.asList(9,8,7,6,5,4,3,2,1);

//         System.out.println("Arranjo antes-:>"+arr.toString());
        // Comprar cada carta
        for (int i = 1; i < arr.size(); i++) { // n
            // Carta comprada
            int seguro = arr.get(i); // n
            
            // Deslocar cartas para a direita, para abrir o espaço
            // correto da carta comprada.
            int j = i-1; // n
            while (j >= 0 && seguro < arr.get(j)) { // n * n
//                 medicoes.qtdeComps++;                
//                 medicoes.qtdeEscrs++;
                arr.set(j+1,arr.get(j)); //n * n
                j--;// n * n
            }
//             medicoes.qtdeComps++;
            
            // Colocar a carta no lugar
//             medicoes.qtdeEscrs++;
            arr.set(j+1,seguro ); // n
        }
        
        return arr;
    }
    
    /**
     * Método ordena crescentemente o arranjo utilizando o algoritmo de quicksort, in place.
     * 
     * @param arr arranjo a ser ordenado in place. Não pode ser nulo.
     */
    public static void quicksort(int[] arr){

        quicksort(arr, 0, arr.length);

    }
    
    /**
     * Método Helper do quicksort, ordena crescentemente o subarranjo arr [l,r) utilizando o 
     * algortimo de quicksort, in place.
     * 
     * @param arr arranjo a ser ordenado
     * @param l indice inicial do subarranjo a ser ordenado, inclusivo
     * @param r indice final do subarranjo a ser ordenado, exclusivo
     */
    public static void quicksort(int[] arr, int l, int r){
        if( r - 1 <= 1) return;
        
        int pivo = escolherPivo(arr, l, r);
        pivo = particionar(arr, l, r, pivo);
        quicksort(arr, l, pivo);
        quicksort(arr, pivo, r);
    }
    
    /**
     * Escolhe um índice como pivo para o quicksort, dentro do limite do subarranjo de arr [l,r).
     * Não há garantias sobre qual elemento dentro desse feixe será selecionado.
     * 
     * @param arr arranjo a ser ordenado
     * @param l indice inicial do subarranjo, inclusivo
     * @param r indice final do subarranjo, exclusivo
     */
    private static int escolherPivo(int[] arr, int l, int r){
        int h = (l + r) / 2;
        if(arr[l] <= arr[r-1] && arr[l] >= arr[h])
            return l;
        if(arr[r-1] <= arr[l] && arr[r-1] >= arr[h])
            return r-1;
        else
            return h;
    }        
    
    private static int particionar(int[] arr, int l, int r, int pivo){
        trocar(arr, pivo, r - 1);
        pivo = r - 1;
        
        r--;
        while( l < r ){
            while(arr[l] <= arr[pivo])l++;
            while(arr[r] > arr[pivo])r--;
            
            trocar(arr, l, r-1);
        }
        
        trocar(arr, pivo, l);
        return l;
    }
    
    private static void trocar(int[] arr, int i, int j) {
        int seguro = arr[i];
        arr[i] = arr[j];
        arr[j] = seguro;
    }
    
    /**
     * Ordena crescentemente o arranjo pelo algoritmo de quicksort,
     * in-place.
     * 
     * @param arranjo arranjo de inteiros a ser ordenado.
     */
    public static void Listquicksort() {
        List<Integer> arranjo = Arrays.asList(9,8,7,6,5,4,3,2,1);
        System.out.println("Antes->"+ arranjo.toString());
        Listquicksort(arranjo, 0, arranjo.size()-1);
        System.out.println("Depois->:"+ arranjo.toString());
    }
    
    /**
     * Ordena crescentemente o arranjo pelo algoritmo de quicksort,
     * in-place. Método recursivo.
     * 
     * @param arranjo arranjo de inteiros a ser ordenado.
     * @param indiceEsquerda índice do lado esquerdo.
     * @param indiceDireita índice do lado direito.
     */
    public static void Listquicksort(List<Integer> arranjo, int indiceEsquerda, int indiceDireita) {
        
        if (indiceEsquerda < indiceDireita){
            int principal = arranjo.get((indiceEsquerda + indiceDireita)/2);
            int indice = Listparticionar(arranjo, indiceEsquerda, indiceDireita, principal);
            Listquicksort(arranjo, indiceEsquerda, indice - 1);
            Listquicksort(arranjo, indice, indiceDireita);
        }
        
    }
    
    /**
     * Particiona os elementos do arranjo de acordo com um elemento
     * principal escolhido e retorna o índice do ponto onde
     * o arranjo foi particionado.
     * 
     * @param arranjo arranjo de inteiros a ser ordenado.
     * @param indiceEsquerda índice do lado esquerdo.
     * @param indiceDireita índice do lado direito.
     */
    public static int Listparticionar(List<Integer> arranjo, int indiceEsquerda, int indiceDireita, int principal) {
        int pivot = (indiceEsquerda + indiceDireita)/2;
        List<Integer> marcadores =  Arrays.asList(indiceEsquerda, indiceDireita, pivot);
       
        
        while (indiceEsquerda <= indiceDireita){
            while (arranjo.get(indiceEsquerda) < principal){
                indiceEsquerda++;
            }
            while (arranjo.get(indiceDireita) > principal){
                indiceDireita--;
            }
           
            if (indiceEsquerda <= indiceDireita){
                Listtrocar(arranjo, indiceEsquerda++, indiceDireita--);
            }
        }
  
        return indiceEsquerda;
    }
    
    
    
    
    
    
    
    
    private static void Listtrocar(List<Integer> arr, int i, int j) {
        int seguro = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, seguro);
    }
    
     /**
     * Ordena crescentemente o arranjo pelo algoritmo da intercalação,
     * in-place.
     * @param arranjo arranjo de inteiros a ser ordenado.
     */
    public static void ListmergeSort() {
        List<Integer> arranjo = Arrays.asList(9,8,7,6,5,4,3,2,1); 
        
        System.out.println("Antes->"+arranjo);
        
        List<Integer> copiaArrajo = new ArrayList(arranjo);//copaiaaadadasdadas
        
        ListmergeSort(arranjo, copiaArrajo, 0, arranjo.size()-1);
        System.out.println("Depois->"+arranjo);
    }
    
        /**
     * Ordena crescentemente o arranjo pelo algoritmo da intercalação,
     * in-place. Método recursivo.
     * 
     * @param arranjo arranjo de inteiros a ser ordenado.
     * @param aux arranjo auxiliar.
     * @param inicio indice inicial.
     * @param fim indice final.
     */
    public static void ListmergeSort(List<Integer> arranjo, List<Integer> aux, int inicio, int fim) {
        if (inicio < fim){
            int meio = (inicio+fim)/2;
            ListmergeSort(arranjo, aux, inicio, meio);
            ListmergeSort(arranjo, aux, meio+1, fim);
            Listintercalar(arranjo, aux, inicio, fim);
        }
    }
    
    public static void Listintercalar(List<Integer> arranjo, List<Integer> aux, int inicio, int fim) {
        int[] marcadores = {inicio, fim};
   
        int meio = (inicio+fim)/2;
        int inicioDireita = meio + 1;
        int tamanho = fim - inicio + 1;
        
        // Controles de índices de cada metade do arranjo
        int indiceEsquerda = inicio;
        int indiceDireita = inicioDireita;
        int indiceArray = inicio;
        
        // Enquanto as duas metades ainda possuem elementos, intercala.
        while (indiceEsquerda <= meio && indiceDireita <= fim){
            
            if (arranjo.get(indiceEsquerda) < arranjo.get(indiceDireita)){
               
                aux.set(indiceArray, arranjo.get(indiceEsquerda));
                indiceArray++;
                indiceEsquerda++;
            } else {
                aux.set(indiceArray, arranjo.get(indiceDireita));
                indiceArray++;
                indiceDireita++;
            }
        }
        // Se o laço anterior acabou, então todos os elementos de uma das metades
        // já foram colocados no arranjo. Os dois laços seguintes terminam de inserir
        // os elementos restantes.
        while(indiceEsquerda <= meio){
            aux.set(indiceArray, arranjo.get(indiceEsquerda) );
            indiceArray++;
            indiceEsquerda++;
        }
        
        while(indiceDireita <= fim){
            aux.set(indiceArray, arranjo.get(indiceDireita));
            indiceArray++;
            indiceDireita++;
        }
        
        // Copia os elementos ordenados do arranjo auxiliar para o arranjo original.
        for (int i = inicio; i<inicio+tamanho; i++){
            arranjo.set(i, aux.get(i));
        }
    }
    
    
    /**
     * Essa classe não deve ser instanciada.
     */
    private Ordenacoes() {}
}
