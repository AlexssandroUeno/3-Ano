import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Color;

/**
 * Write a description of class ArranjoGravado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArranjoGravado implements Transparencia
{
    /**
     * Constructor for objects of class ArranjoGravado
     */
    public ArranjoGravado(int[] arranjo, Color[] corIdxs, String nome) {
        this.arranjo = arranjo;
        this.nome = nome;
        this.corIdxs = corIdxs;
    }
    
    
    public void pintar(Graphics2D pincel, JPanel contexto) {
        Dimension dim = contexto.getSize();
        
        throw new UnsupportedOperationException("Funcionalidade ainda não implementada pelo aluno");
    }
    
    
    private int[] arranjo;
    private Color[] corIdxs;
    private String nome;
}
