import java.util.ListIterator;

/**
 * Write a description of class AlgoritmosAnimados here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AlgoritmosAnimados
{
    public static Gravador buscaSequencial(int[] arranjo, int chave) {
        Gravador anim = new Gravador();
        anim.gravarArranjo(arranjo, "Inicio de busca sequencial");
        
        int i = 0;
        anim.gravarIndiceDestacado(arranjo, i, "Busca sequencial");
        while (i < arranjo.length && arranjo[i] != chave) {
            i++;
            anim.gravarIndiceDestacado(arranjo, i, "Busca sequencial");
        }
        
        if (i < arranjo.length) {
            anim.gravarIndiceDestacado(arranjo, i, "Chave encontrada");
        } else {
            anim.gravarArranjo(arranjo, "Chave não encontrada");
        }
        
        return anim;
    }
    
    
    public static Gravador ordenarPorBolha(int[] arranjo) {
        //Gravador anim = new Gravador();
        //anim.gravarArranjo(arranjo, "Disposição inicial");
        
        throw new UnsupportedOperationException("Funcionalidade ainda não implementada pelo aluno");
        
        //anim.gravarArranjo(arranjo, "Disposição final");
        //return anim;
    }
}