import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;
import java.awt.Color;

/**
 * Write a description of class Gravador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Gravador
{
    public Gravador() {
        this.seqGravacoes = new LinkedList<Transparencia>();
    }

    public void gravarArranjo(int[] arranjo, String nome) {
        int[] copia = Arrays.copyOf(arranjo, arranjo.length);
        Color[] cores = new Color[arranjo.length];
        ArranjoGravado gravacao = new ArranjoGravado(copia, cores, nome);
        seqGravacoes.add(gravacao);
    }

    public void gravarIndiceDestacado(int[] arranjo, int i, String nome) {
        int[] copia = Arrays.copyOf(arranjo, arranjo.length);
        Color[] cores = new Color[arranjo.length];
        cores[i] = Color.YELLOW;
        ArranjoGravado gravacao = new ArranjoGravado(copia, cores, nome);
        seqGravacoes.add(gravacao);
    }

    public void gravarComparacaoSimples(int[] arranjo, int i, int j) {
        int[] copia = Arrays.copyOf(arranjo, arranjo.length);
        Color[] cores = new Color[arranjo.length];
        cores[i] = cores[j] = Color.GRAY;
        ArranjoGravado gravacao = new ArranjoGravado(copia, cores, "Comparação");
        seqGravacoes.add(gravacao);
    }

    public void gravarPosTrocas(int[] arranjo, int i, int j) {
        int[] copia = Arrays.copyOf(arranjo, arranjo.length);
        Color[] cores = new Color[arranjo.length];
        cores[i] = cores[j] = Color.YELLOW;
        ArranjoGravado gravacao = new ArranjoGravado(copia, cores, "Pós-troca");
        seqGravacoes.add(gravacao);
    }

    public ListIterator<Transparencia> getFilme() {
        return seqGravacoes.listIterator();
    }

    private LinkedList<Transparencia> seqGravacoes;
}
