import javax.swing.JPanel;
import java.awt.Graphics2D;

/**
 * Write a description of class FramedArray here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Transparencia
{
    void pintar(Graphics2D g2d, JPanel contexto);
}
