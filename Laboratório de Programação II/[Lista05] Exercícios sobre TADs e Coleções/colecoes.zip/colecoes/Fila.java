
/**
 * Write a description of interface Fila here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Fila {
    /**
     * Escrever um javadoc adequado aqui...
     */
    void enfileirar(Object objeto);
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object desenfileirar();
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object primeiro();
}
