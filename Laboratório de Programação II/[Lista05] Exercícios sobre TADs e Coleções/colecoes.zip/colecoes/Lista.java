
/**
 * Write a description of interface Lista here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Lista {
    /**
     * Escrever um javadoc adequado aqui...
     */
    int inserir(Object o, int pos);
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object remover(int pos);
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    int buscar(Object o);
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object itemEm(int pos);
}
