
/**
 * Write a description of interface Pilha here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Pilha {
    /**
     * Escrever um javadoc adequado aqui...
     */
    void empilhar(Object o);
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object desempilhar();
    
    /**
     * Escrever um javadoc adequado aqui...
     */
    Object topo();
}
