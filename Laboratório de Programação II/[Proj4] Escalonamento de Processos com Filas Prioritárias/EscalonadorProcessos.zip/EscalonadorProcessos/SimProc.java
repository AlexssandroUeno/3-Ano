

/**
 * Write a description of class SimProc here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SimProc
{
    public static void main(String[] args) {
        // Argumentos de linha de comando são tratados aqui
        
        // Após tratamento, chamar métodos adequados para executar simulação
        // e imprimir na tela resultados
        
        throw new UnsupportedOperationException("O aluno ainda não implementou as funcionalidades de linha de comando");
    }
}
